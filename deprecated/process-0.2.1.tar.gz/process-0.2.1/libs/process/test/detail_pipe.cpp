// Boost.Process
// Tests for the detail::pipe class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "boost/process/detail/pipe.hpp"
#include "boost/process/iostreams_pipe_end_traits.hpp"
#include "boost/process/pipe_end.hpp"
#include "boost/iostreams/stream.hpp"
#include "boost/test/unit_test.hpp"

namespace bios = boost::iostreams;
namespace bp = boost::processes;
namespace bpd = boost::processes::detail;
namespace butf = boost::unit_test::framework;

namespace {

void test_read_and_write()
{
    bpd::pipe p;
    // XXX This assumes that the pipe's buffer is big enough to accept
    // the data written without blocking!
    bios::stream<bp::pipe_end> os(p.wend());
    os << "test";
    os.close();
    p.wend().close();
    bios::stream<bp::pipe_end> is(p.rend());
    std::string word;
    is >> word;
    BOOST_CHECK_EQUAL(word, "test");
}

} // namespace {

bool init_unit_test()
{
    butf::master_test_suite().add(BOOST_TEST_CASE(test_read_and_write));
    return true;
}
