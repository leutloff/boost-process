// Boost.Process
// Tests for the posix::launch class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "boost/process/config.hpp"

#if defined(BOOST_POSIX_API)

#include "launch.hpp"
#include "util/use_helpers.hpp"
#include "util/unit_test_main.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/launch.hpp"
#include "boost/filesystem/operations.hpp"
#include "boost/format.hpp"
#include "boost/iostreams/stream.hpp"
#include "boost/test/unit_test.hpp"
#include "boost/variant/get.hpp"
#include <cstring>
#include <string>

namespace bfs = boost::filesystem;
namespace bp = boost::processes;
namespace bios = boost::iostreams;
namespace butf = boost::unit_test::framework;

namespace {

struct launcher
{
    bp::child
    operator()(const std::vector<std::string> args,
               const bp::context& ctx,
               bool = false) const
    {
        return bp::launch(get_helpers_path(), args, ctx);
    }
};

void test_input()
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("stdin-to-stdout");

    bp::context ctx;
    ctx.add(bp::capture_stream(bp::stdin_fileno))
       .add(bp::capture_stream(bp::stdout_fileno));
    bp::child c = bp::launch(get_helpers_path(), args, ctx);

    bios::stream<bp::pipe_end> os(c.get_pipe_end(bp::stdin_fileno));
    bios::stream<bp::pipe_end> is(c.get_pipe_end(bp::stdout_fileno));

    os << "message-to-process" << std::endl;
    os.close();
    c.get_pipe_end(bp::stdin_fileno).close();

    std::string word;
    is >> word;
    BOOST_CHECK_EQUAL(word, "message-to-process");

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

void check_output(int desc, const std::string& msg)
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("posix-echo-one");
    args.push_back(boost::str(boost::format("%1%") % desc));
    args.push_back(msg);

    bp::context ctx;
    ctx.add(bp::capture_stream(desc, bp::capture_stream::out));
    bp::child c = bp::launch(get_helpers_path(), args, ctx);

    bios::stream<bp::pipe_end> is(c.get_pipe_end(desc));
    std::string word;
    is >> word;
    BOOST_CHECK_EQUAL(word, msg);

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

void test_output()
{
    check_output(bp::stdout_fileno, "message1-stdout");
    check_output(bp::stdout_fileno, "message2-stdout");
    check_output(bp::stderr_fileno, "message1-stderr");
    check_output(bp::stderr_fileno, "message2-stderr");
    check_output(10, "message1-10");
    check_output(10, "message2-10");
}

void check_redirect(int desc1, int desc2, const std::string& msg)
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("posix-echo-two");
    args.push_back(boost::str(boost::format("%1%") % desc1));
    args.push_back(boost::str(boost::format("%1%") % desc2));
    args.push_back(msg);

    bp::context ctx;
    ctx.add(bp::capture_stream(desc1, bp::capture_stream::out))
       .add(bp::redirect_to_native_file(desc2, desc1));
    bp::child c = bp::launch(get_helpers_path(), args, ctx);

    bios::stream<bp::pipe_end> is(c.get_pipe_end(desc1));
    int dtmp;
    std::string word;
    is >> dtmp;
    BOOST_CHECK_EQUAL(dtmp, desc1);
    is >> word;
    BOOST_CHECK_EQUAL(word, msg);
    is >> dtmp;
    BOOST_CHECK_EQUAL(dtmp, desc2);
    is >> word;
    BOOST_CHECK_EQUAL(word, msg);

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

void test_redirect()
{
    check_redirect(bp::stdout_fileno, bp::stderr_fileno, "message");
    check_redirect(bp::stderr_fileno, bp::stdout_fileno, "message");
    check_redirect(4, 5, "message");
    check_redirect(10, 20, "message");
}

void test_default_ids()
{
    bp::context ctx;
    BOOST_CHECK_EQUAL(ctx.egid, ::getegid());
    BOOST_CHECK_EQUAL(ctx.euid, ::geteuid());
}

} // namespace {

bool init_unit_test()
{
    check_helpers();
    launch_tests::add<launcher, bp::context, bp::child>
        (butf::master_test_suite());
    butf::master_test_suite().add(BOOST_TEST_CASE(test_output), 0, 10);
    butf::master_test_suite().add(BOOST_TEST_CASE(test_redirect), 0, 10);
    butf::master_test_suite().add(BOOST_TEST_CASE(test_input), 0, 10);
    butf::master_test_suite().add(BOOST_TEST_CASE(test_default_ids));
    return true;
}

#else // #if defined(BOOST_POSIX_API)

int main() { return 0; }

#endif // #if defined(BOOST_POSIX_API)
