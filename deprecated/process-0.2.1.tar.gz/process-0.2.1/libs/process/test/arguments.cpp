// Boost.Process
// Tests for command line construction class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "util/use_helpers.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/iostreams_pipe_end_traits.hpp"
#include "boost/process/launch.hpp"
#include "boost/process/status.hpp"
#include "boost/iostreams/stream.hpp"
#include "boost/test/unit_test.hpp"
#if defined(BOOST_POSIX_API)
    #include "boost/process/detail/posix_util.hpp"
    #include <cstddef>
#elif defined(BOOST_WINDOWS_API)
    #include "boost/process/detail/windows_util.hpp"
    #include <windows.h>
#endif
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

namespace bp = boost::processes;
namespace bpd = boost::processes::detail;
namespace bios = boost::iostreams;
namespace butf = boost::unit_test::framework;

namespace {

std::string get_argument(const std::string& word)
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("echo-quoted");
    args.push_back(word);

    bp::context ctx;
    ctx.streams_behavior.push_back(bp::capture_stream(bp::stdout_fileno));
    bp::child c = bp::launch(get_helpers_path(), args, ctx);

    bios::stream<bp::pipe_end> is(c.get_stdout());
    std::string result;
    std::getline(is, result);

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);

    return result;
}

void test_quoting()
{
    BOOST_CHECK_EQUAL(get_argument("foo"), ">>>foo<<<");
    BOOST_CHECK_EQUAL(get_argument("foo "), ">>>foo <<<");
    BOOST_CHECK_EQUAL(get_argument(" foo"), ">>> foo<<<");
    BOOST_CHECK_EQUAL(get_argument("foo bar"), ">>>foo bar<<<");

    BOOST_CHECK_EQUAL(get_argument("foo\"bar"), ">>>foo\"bar<<<");
    BOOST_CHECK_EQUAL(get_argument("foo\"bar\""), ">>>foo\"bar\"<<<");
    BOOST_CHECK_EQUAL(get_argument("\"foo\"bar"), ">>>\"foo\"bar<<<");
    BOOST_CHECK_EQUAL(get_argument("\"foo bar\""), ">>>\"foo bar\"<<<");

    BOOST_CHECK_EQUAL(get_argument("*"), ">>>*<<<");
    BOOST_CHECK_EQUAL(get_argument("?*"), ">>>?*<<<");
    BOOST_CHECK_EQUAL(get_argument("[a-z]*"), ">>>[a-z]*<<<");
}

#if defined(BOOST_POSIX_API)
void test_collection_to_posix_argv()
{
    std::vector<std::string> args;
    args.push_back("program");
    args.push_back("arg1");
    args.push_back("arg2");
    args.push_back("arg3");

    std::pair<std::size_t, char**> p = bpd::vector_to_argv(args);
    std::size_t argc = p.first;
    char** argv = p.second;

    BOOST_REQUIRE_EQUAL(argc, static_cast<std::size_t>(4));

    BOOST_REQUIRE(std::strcmp(argv[0], "program") == 0);
    BOOST_REQUIRE(std::strcmp(argv[1], "arg1") == 0);
    BOOST_REQUIRE(std::strcmp(argv[2], "arg2") == 0);
    BOOST_REQUIRE(std::strcmp(argv[3], "arg3") == 0);
    BOOST_REQUIRE(argv[4] == 0);

    delete [] argv[0];
    delete [] argv[1];
    delete [] argv[2];
    delete [] argv[3];
    delete [] argv;
}
#endif // #if defined(BOOST_POSIX_API)

#if defined(BOOST_WINDOWS_API)
void test_collection_to_windows_cmdline()
{
    std::vector<std::string> args;
    args.push_back("program");
    args.push_back("arg1");
    args.push_back("arg2");
    args.push_back("arg3");

    boost::shared_array<char> cmdline =
        bpd::vector_to_windows_cmdline(args);
    BOOST_REQUIRE(std::strcmp(cmdline.get(), "program arg1 arg2 arg3") == 0);
}
#endif // #if defined(BOOST_WINDOWS_API)

} // namespace {

bool init_unit_test()
{
    check_helpers();
    butf::master_test_suite().add(BOOST_TEST_CASE(test_quoting));
#if defined(BOOST_POSIX_API)
    butf::master_test_suite()
        .add(BOOST_TEST_CASE(test_collection_to_posix_argv));
#elif defined(BOOST_WINDOWS_API)
    butf::master_test_suite()
        .add(BOOST_TEST_CASE(test_collection_to_windows_cmdline));
#endif
    return true;
}
