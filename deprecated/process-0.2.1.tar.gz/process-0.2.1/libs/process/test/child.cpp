// Boost.Process
// Tests for the child class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "child.hpp"
#include "util/unit_test_main.hpp"
#include "util/use_helpers.hpp"
#include "boost/process/child.hpp"
#include "boost/process/process.hpp"
#include "boost/test/unit_test.hpp"

namespace bp = boost::processes;
namespace bpd = boost::processes::detail;
namespace butf = boost::unit_test::framework;

namespace {

struct launcher
{
    bp::child
    operator()(bp::child::native_type native) const
    {
        bp::pipe_end invalidfh;
        return bp::child(native, invalidfh, invalidfh, invalidfh);
    }

    bp::child
    operator()(bp::child::native_type native,
               bp::pipe_end stdinfh,
               bp::pipe_end stdoutfh,
               bp::pipe_end stderrfh) const
    {
        return bp::child(native, stdinfh, stdoutfh, stderrfh);
    }
};

} // namespace {

bool init_unit_test()
{
    check_helpers();
    child_tests::add<bp::child, launcher>(butf::master_test_suite());
    return true;
}
