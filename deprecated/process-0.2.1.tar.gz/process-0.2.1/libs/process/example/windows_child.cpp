// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

// This example program demonstrates how to start a process in a Windows
// operating system and later retrieve handles and identifiers to both
// the process and its primary thread.

// Avoid building this example under non-Windows systems.
#include "boost/process/config.hpp"
#if defined(BOOST_WINDOWS_API)

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#include "boost/process.hpp"

namespace bp = boost::processes;

int main(int argc, char* argv[])
{
    int exitstatus = EXIT_FAILURE;

    try {
        // Constructs a command line to launch Notepad, looking for its
        // availability in the PATH.
        //
        std::string exe = bp::find_executable_in_path("notepad");
        std::vector<std::string> args;
        args.push_back("notepad");

        // Starts the process.
        //
        bp::child c = bp::launch(exe, args, bp::context());

        // Prints out information about the new process.
        //
        std::cout << "Process handle : 0x" << c.native() << std::endl;

        // Waits until the process terminates and reports status.
        //
        const bp::status s = c.wait();
        if (s.exited()) {
            std::cout << "Application exited successfully" << std::endl;
            exitstatus = EXIT_SUCCESS;
        } else {
            std::cout << "The application returned an error" << std::endl;
        }
    } catch (const boost::system::system_error&) {
        std::cout << "Could not find notepad in path." << std::endl;
    }

    return exitstatus;
}
//]

#else // !defined(BOOST_WINDOWS_API)

#include <cstdlib>
#include <iostream>

int main(int argc, char* argv[])
{
    std::cerr << "This example program is not supported in this platform."
              << std::endl;
    return EXIT_FAILURE;
}

#endif // defined(BOOST_WINDOWS_API)
