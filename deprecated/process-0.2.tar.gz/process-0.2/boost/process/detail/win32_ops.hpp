// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

/// \file boost/process/detail/win32_ops.hpp
///
/// Provides some convenience functions to start processes under Win32
/// operating systems.

#ifndef BOOST_PROCESS_WIN32_OPS_HPP_170710
#define BOOST_PROCESS_WIN32_OPS_HPP_170710

#include "boost/process/config.hpp"
#if !defined(BOOST_PROCESS_WIN32_API)
    #error "Unsupported platform."
#endif
#include "boost/process/detail/pipe.hpp"
#include "boost/process/child.hpp"
#include "boost/process/environment.hpp"
#include "boost/process/exceptions.hpp"
#include "boost/process/stream_behavior.hpp"
#include "boost/iostreams/device/file_descriptor.hpp"
#include "boost/scoped_array.hpp"
#include "boost/shared_array.hpp"
#include "boost/throw_exception.hpp"
#include "boost/variant/apply_visitor.hpp"
#include "boost/variant/static_visitor.hpp"
#include <tchar.h>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

namespace boost {
namespace process {
namespace detail {

/// \brief Converts the command line to a plain string.
///
/// Converts the command line's list of arguments to the format
/// expected by the \a lpCommandLine parameter in the CreateProcess()
/// system call.
///
/// This operation is only available in Win32 systems.
///
/// \return A dynamically allocated string holding the command line
///         to be passed to the executable. It is returned in a
///         shared_array object to ensure its release at some point.
template<class Arguments>
boost::shared_array<TCHAR>
collection_to_win32_cmdline(const Arguments& args)
{
    typedef std::vector<std::string> arguments_vector;
    Arguments args2;

    typename Arguments::size_type i = 0;
    std::size_t length = 0;
    for (typename Arguments::const_iterator iter = args.begin();
         iter != args.end(); iter++) {
        std::string arg = (*iter);

        std::string::size_type pos = 0;
        while ((pos = arg.find('"', pos)) != std::string::npos) {
            arg.replace(pos, 1, "\\\"");
            pos += 2;
        }

        if (arg.find(' ') != std::string::npos)
            arg = '\"' + arg + '\"';

        if (i != args.size() - 1)
            arg += ' ';

        args2.push_back(arg);
        length += arg.size() + 1;

        i++;
    }

    boost::shared_array<TCHAR> cmdline(new TCHAR[length]);
    ::_tcscpy_s(cmdline.get(), length, TEXT(""));
    for (arguments_vector::size_type i = 0; i < args2.size(); i++)
        ::_tcscat_s(cmdline.get(), length, TEXT(args2[i].c_str()));

    return cmdline;
}

/// \brief Converts an environment to a string used by CreateProcess().
///
/// Converts the environment's contents to the format used by the
/// CreateProcess() system call. The returned TCHAR* string is
/// allocated in dynamic memory and the caller must free it when not
/// used any more. This is enforced by the use of a shared pointer.
/// The string is of the form var1=value1\\0var2=value2\\0\\0.
///
inline
boost::shared_array<TCHAR>
environment_to_win32_strings(const environment& env)
{
    boost::shared_array<TCHAR> strs(0);

    // TODO: Add the "" variable to the returned string; it shouldn't
    // be in the environment if the user didn't add it.

    if (env.size() == 0) {
        strs.reset(new TCHAR[2]);
        ::ZeroMemory(strs.get(), sizeof(TCHAR) * 2);
    } else {
        std::string::size_type len = sizeof(TCHAR);
        for (environment::const_iterator iter = env.begin();
             iter != env.end(); iter++)
            len += (iter->first.length() + 1 + iter->second.length() +
                    1) * sizeof(TCHAR);

        strs.reset(new TCHAR[len]);

        TCHAR* ptr = strs.get();
        for (environment::const_iterator iter = env.begin();
             iter != env.end(); iter++) {
            std::string tmp = iter->first + "=" + iter->second;
            _tcscpy_s(ptr, len - (ptr - strs.get()) * sizeof(TCHAR),
                      TEXT(tmp.c_str()));
            ptr += (tmp.length() + 1) * sizeof(TCHAR);

            BOOST_ASSERT(static_cast<std::string::size_type>
                (ptr - strs.get()) * sizeof(TCHAR) < len);
        }
        *ptr = '\0';
    }

    BOOST_ASSERT(strs.get() != 0);
    return strs;
}

template<DWORD StdHandle>
struct stream_info_visitor: boost::static_visitor<>
{
    stream_info_visitor(boost::iostreams::file_descriptor& fh,
                        boost::iostreams::file_descriptor& fhout,
                        boost::iostreams::file_descriptor& ph)
    : fh_(fh)
    , fhout_(fhout)
    , ph_(ph)
    {}

    void operator()(close_stream) const
    {
        // do nothing
    }

    void operator()(inherit_stream) const
    {
        fh_ = win32_std_fd(StdHandle, true);
    }

    void operator()(redirect_stream_to_stdout) const
    {
        BOOST_ASSERT(is_valid_fd(fhout_));
        fh_ = win32_dup_fd(fhout_, true);
    }

    void operator()(use_handle sb) const
    {
        fh_ = sb.file_descriptor();
        win32_set_inheritable_fd(fh_, true);
    }

protected:
    boost::iostreams::file_descriptor& fh_;
    boost::iostreams::file_descriptor& fhout_;
    boost::iostreams::file_descriptor& ph_;
};

template<DWORD StdHandle>
struct input_stream_info_visitor: stream_info_visitor<StdHandle>
{
    input_stream_info_visitor(boost::iostreams::file_descriptor& fh,
                              boost::iostreams::file_descriptor& fhout,
                              boost::iostreams::file_descriptor& ph)
    : stream_info_visitor(fh, fhout, ph)
    {}

    using stream_info_visitor<StdHandle>::operator();

    void operator()(silence_stream) const
    {
        (*this)(use_file("NUL"));
    }

    void operator()(use_file sb) const
    {
        HANDLE h = ::CreateFile(TEXT(sb.file().c_str()), GENERIC_READ,
                                0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
        if (h == INVALID_HANDLE_VALUE)
            boost::throw_exception
                (system_error("boost::process::detail::win32_start",
                              "CreateFile failed", ::GetLastError()));
        fh_ = boost::iostreams::file_descriptor(h, true);
    }

    void operator()(capture_stream) const
    {
        pipe p;
        win32_set_inheritable_fd(p.rend(), true);
        fh_ = p.rend();
        ph_ = p.wend();
    }
};

template<DWORD StdHandle>
struct output_stream_info_visitor: stream_info_visitor<StdHandle>
{
    output_stream_info_visitor(boost::iostreams::file_descriptor& fh,
                               boost::iostreams::file_descriptor& fhout,
                               boost::iostreams::file_descriptor& ph)
    : stream_info_visitor(fh, fhout, ph)
    {}

    using stream_info_visitor<StdHandle>::operator();

    void operator()(silence_stream) const
    {
        (*this)(use_file("NUL"));
    }

    void operator()(use_file sb) const
    {
        HANDLE h = ::CreateFile(TEXT(sb.file().c_str()), GENERIC_WRITE,
                                0, 0, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, 0);
        if (h == INVALID_HANDLE_VALUE)
            boost::throw_exception
                (system_error("boost::process::detail::win32_start",
                              "CreateFile failed", ::GetLastError()));
        fh_ = boost::iostreams::file_descriptor(h, true);
    }

    void operator()(capture_stream) const
    {
        pipe p;
        win32_set_inheritable_fd(p.wend(), true);
        fh_ = p.wend();
        ph_ = p.rend();
    }
};

/// \brief Starts a new child process in a Win32 operating system.
///
/// This helper functions is provided to simplify the Launcher's task when
/// it comes to starting up a new process in a Win32 operating system.
///
/// \param cl The command line used to execute the child process.
/// \param env The environment variables that the new child process
///            receives.
/// \param ctx The context for the new child process.
/// \return win32::child instance corresponding to the new process.
/// \pre \a ctx.startupinfo cannot have the \a STARTF_USESTDHANDLES set
///      in the \a dwFlags field.
///
template<class Executable, class Arguments, class Context>
child
win32_start(const Executable& exe,
            const Arguments& args,
            const Context& ctx)
{
    STARTUPINFO* si;
    STARTUPINFO si1;
    boost::scoped_array<char> si2;
    if (ctx.startupinfo) {
        BOOST_ASSERT(ctx.startupinfo->cb >= sizeof(STARTUPINFO));
        BOOST_ASSERT(!(ctx.startupinfo->dwFlags & STARTF_USESTDHANDLES));
        si2.reset(new char[ctx.startupinfo->cb]);
        ::CopyMemory(si2.get(), ctx.startupinfo, ctx.startupinfo->cb);
        si = static_cast<STARTUPINFO*>(static_cast<void*>(si2.get()));
    } else {
        si = &si1;
        ::ZeroMemory(si, sizeof(si1));
        si->cb = sizeof(si1);
    }
    si->dwFlags |= STARTF_USESTDHANDLES;

    boost::iostreams::file_descriptor chin, chout, cherr;
    boost::iostreams::file_descriptor stdinfh, stdoutfh, stderrfh;

    input_stream_info_visitor<STD_INPUT_HANDLE> isiv(chin, chout, stdinfh);
    boost::apply_visitor(isiv, ctx.stdin_behavior);
    si->hStdInput = is_valid_fd(chin) ? chin.handle() : INVALID_HANDLE_VALUE;
    output_stream_info_visitor<STD_OUTPUT_HANDLE> osov(chout, chout, stdoutfh);
    boost::apply_visitor(osov, ctx.stdout_behavior);
    si->hStdOutput = is_valid_fd(chout) ? chout.handle() : INVALID_HANDLE_VALUE;
    output_stream_info_visitor<STD_ERROR_HANDLE> esov(cherr, chout, stderrfh);
    boost::apply_visitor(esov, ctx.stderr_behavior);
    si->hStdError = is_valid_fd(cherr) ? cherr.handle() : INVALID_HANDLE_VALUE;

    PROCESS_INFORMATION pi;
    ::ZeroMemory(&pi, sizeof(pi));

    boost::shared_array<TCHAR> cmdline = collection_to_win32_cmdline(args);
    boost::scoped_array<TCHAR> executable(::_tcsdup(TEXT(exe.c_str())));
    boost::scoped_array<TCHAR> workdir
        (::_tcsdup(TEXT(ctx.work_directory.c_str())));
    boost::shared_array<TCHAR> envstrs(
        environment_to_win32_strings(ctx.environment));
    if (!::CreateProcess(executable.get(), cmdline.get(), 0, 0, TRUE,
                         0, envstrs.get(), workdir.get(),
                         si, &pi)) {
        boost::throw_exception
            (system_error("boost::process::detail::win32_start",
                          "CreateProcess failed", ::GetLastError()));
    }
    ::CloseHandle(pi.hThread); // FIXME: check for errors
    return child(pi.hProcess, stdinfh, stdoutfh, stderrfh);
}

} // namespace detail
} // namespace process
} // namespace boost

#endif
