// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

/// \file boost/process/detail/posix_ops.hpp
///
/// Provides some convenience functions to start processes under POSIX
/// operating systems.

#ifndef BOOST_PROCESS_POSIX_OPS_HPP_170432
#define BOOST_PROCESS_POSIX_OPS_HPP_170432

#include "boost/process/config.hpp"
#if !defined(BOOST_PROCESS_POSIX_API)
    #error "Unsupported platform."
#endif
#include "boost/process/detail/file_handle.hpp"
#include "boost/process/detail/pipe.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/environment.hpp"
#include "boost/process/exceptions.hpp"
#include "boost/process/stream_behavior.hpp"
#include "boost/scoped_array.hpp"
#include "boost/throw_exception.hpp"
#include "boost/variant/get.hpp"
#include <fcntl.h>
#include <unistd.h>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <map>
#include <set>
#include <utility>

namespace boost {
namespace process {
namespace detail {

/// \brief Converts the command line to an array of C strings.
///
/// Converts the command line's list of arguments to the format expected
/// by the \a argv parameter in the POSIX execve() system call.
///
/// This operation is only available in POSIX systems.
///
/// \return The first argument of the pair is an integer that indicates
///         how many strings are stored in the second argument. The
///         second argument is a null-terminated, dynamically allocated
///         vector of dynamically allocated strings holding the arguments
///         to the executable. The caller is responsible of freeing them.
template<class Arguments>
std::pair<std::size_t, char**>
collection_to_posix_argv(const Arguments& args)
{
    std::size_t nargs = args.size();
    BOOST_ASSERT(nargs > 0);

    char** argv = new char*[nargs + 1];
    typename Arguments::size_type i = 0;
    for (typename Arguments::const_iterator iter = args.begin();
         iter != args.end(); iter++) {
        argv[i] = ::strdup(iter->c_str());
        i++;
    }
    argv[nargs] = 0;

    return std::pair<std::size_t, char **>(nargs, argv);
}

/// \brief Converts an environment to a char** table as used by execve().
///
/// Converts the environment's contents to the format used by the
/// execve() system call. The returned char** array is allocated
/// in dynamic memory and the caller must free it when not used any
/// more. Each entry is also allocated in dynamic memory and is a
/// null-terminated string of the form var=value; these must also be
/// released by the caller.
///
BOOST_PROCESS_DECL
char** environment_to_envp(const environment& env);

/// Holds a mapping between native file descriptors and their corresponding
/// pipes to set up communication between the parent and the %child process.
///
typedef std::map<int, pipe> communication_pipes;

/// \brief Configures child process' input streams.
///
/// Sets up the current process' input streams to behave according to the
/// information in the \a behavior map. \a closeflags is modified to reflect
/// those descriptors that should not be closed because they where modified
/// by the function.
///
/// Modifies the current execution environment, so this should only be run
/// on the child process after the fork(2) has happened.
///
/// \throw system_error If any error occurs during the configuration.
///
BOOST_PROCESS_DECL void
setup_input(const behavior_map& bm,
            communication_pipes& input_pipes,
            bool* closeflags,
            int maxdescs);

/// \brief Configures child process' output streams.
///
/// Sets up the current process' output streams to behave according to the
/// information in the \a behavior map. \a closeflags is modified to reflect
/// those descriptors that should not be closed because they where modified
/// by the function.
///
/// Modifies the current execution environment, so this should only be run
/// on the child process after the fork(2) has happened.
///
/// \throw system_error If any error occurs during the configuration.
///
BOOST_PROCESS_DECL void
setup_output(const behavior_map& bm,
             communication_pipes& output_pipes,
             bool* closeflags,
             int maxdescs);

/// \brief Starts a new child process in a POSIX operating system.
///
/// This helper functions is provided to simplify the Launcher's task when
/// it comes to starting up a new process in a POSIX operating system.
/// The function hides all the details of the fork/exec pair of calls as
/// well as all the setup of communication pipes and execution environment.
///
/// \param cl The command line used to execute the child process.
/// \param env The environment variables that the new child process
///            receives.
/// \return The new process' PID. The caller is responsible of creating
///         an appropriate Child representation for it.
template<class Executable, class Arguments, class Context>
child
posix_start(const Executable& exe, const Arguments& args, const Context& ctx)
{
    // create pipes
    communication_pipes input_pipes;
    for (behavior_map::const_iterator it = ctx.input_behavior.begin();
         it != ctx.input_behavior.end(); ++it)
        if (boost::get<capture_stream>(&it->second))
            input_pipes.insert(std::make_pair(it->first, pipe()));

    communication_pipes output_pipes;
    for (behavior_map::const_iterator it = ctx.output_behavior.begin();
         it != ctx.output_behavior.end(); ++it)
        if (boost::get<capture_stream>(&it->second))
            output_pipes.insert(std::make_pair(it->first, pipe()));

    pid_t pid = ::fork();
    if (pid == -1) {
        boost::throw_exception
            (system_error("boost::process::detail::posix_start",
                          "fork(2) failed", errno));
    } else if (pid == 0) {
#if defined(F_MAXFD)
        int maxdescs = std::max(::fcntl(0, F_MAXFD), 128); // XXX
#else
        int maxdescs = 128; // XXX
#endif
        try {
            boost::scoped_array<bool> closeflags(new bool[maxdescs]);
            for (int i = 0; i < maxdescs; i++)
                closeflags.get()[i] = true;

            setup_input(ctx.input_behavior,
                        input_pipes,
                        closeflags.get(),
                        maxdescs);
            setup_output(ctx.output_behavior,
                         output_pipes,
                         closeflags.get(),
                         maxdescs);

            for (int i = 0; i < maxdescs; i++)
                if (closeflags.get()[i])
                    ::close(i);

            ctx.apply();

        } catch (const system_error& e) {
            ::write(STDERR_FILENO, e.what(), std::strlen(e.what()));
            ::write(STDERR_FILENO, "\n", 1);
            ::exit(EXIT_FAILURE);
        }

        std::pair<std::size_t, char**> argcv =
            collection_to_posix_argv(args);
        char** envp = environment_to_envp(ctx.environment);
        ::execve(exe.c_str(), argcv.second, envp);
        system_error e("boost::process::detail::posix_start",
                       "execve(2) failed", errno);

        for (std::size_t i = 0; i < argcv.first; i++)
            delete [] argcv.second[i];
        delete [] argcv.second;

        for (std::size_t i = 0; i < ctx.environment.size(); i++)
            delete [] envp[i];
        delete [] envp;

        ::write(STDERR_FILENO, e.what(), std::strlen(e.what()));
        ::write(STDERR_FILENO, "\n", 1);
        ::exit(EXIT_FAILURE);
    }

    BOOST_ASSERT(pid > 0);

    child::file_handle_map input_map;
    for (communication_pipes::iterator it = input_pipes.begin();
         it != input_pipes.end(); ++it)
        input_map.insert(std::make_pair(it->first, it->second.wend()));

    child::file_handle_map output_map;
    for (communication_pipes::iterator it = output_pipes.begin();
         it != output_pipes.end(); ++it)
        output_map.insert(std::make_pair(it->first, it->second.rend()));

    return child(pid, input_map, output_map);
}

} // namespace detail
} // namespace process
} // namespace boost

#ifdef BOOST_PROCESS_HEADER_ONLY
#include "boost/process/detail/impl/posix_ops.hpp"
#endif

#endif
