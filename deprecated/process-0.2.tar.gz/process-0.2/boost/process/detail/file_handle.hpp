// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

/// \file boost/process/detail/file_handle.hpp
///
/// Includes the declaration of the file_handle class. This file is for
/// internal usage only and must not be included by the library user.

#ifndef BOOST_PROCESS_FILE_HANDLE_HPP_165959
#define BOOST_PROCESS_FILE_HANDLE_HPP_165959

#include "boost/process/config.hpp"
#include "boost/iostreams/device/file_descriptor.hpp"

#ifdef BOOST_MSVC
#pragma warning(push)
// 4251 * needs to have dll-interface to be used by clients of *
// 4275 * used as base for dll-interface class *
#pragma warning(disable: 4251 4275)
#endif

namespace boost {
namespace process {
namespace detail {

/// \brief Checks whether the file handle is valid or not.
inline bool
is_valid_fd(const boost::iostreams::file_descriptor& fd)
{
    return fd.handle() !=
#if defined(BOOST_PROCESS_POSIX_API)
        -1
#elif defined(BOOST_PROCESS_WIN32_API)
        reinterpret_cast<void*>(-1);
#endif
    ;
}

#if defined(BOOST_PROCESS_WIN32_API) || defined(BOOST_PROCESS_DOXYGEN)

/// \brief Duplicates the \a h native file handle.
///
/// Given a native file handle \a h, this routine constructs a new
/// \a file_handle object that owns a new duplicate of \a h. The
/// duplicate's inheritable flag is set to the value of \a inheritable.
///
/// This operation is only available in Win32 systems.
///
/// \return A file handle owning a duplicate of \a h.
/// \throw system_error If DuplicateHandle() fails.
///
BOOST_PROCESS_DECL boost::iostreams::file_descriptor
win32_dup_fd(const boost::iostreams::file_descriptor& fd, bool inheritable);

/// \brief Creates a new duplicate of a standard file handle.
///
/// Constructs a new \a file_handle object that owns a duplicate of a
/// standard file handle. The \a d parameter specifies which standard
/// file handle to duplicate and can be one of \a STD_INPUT_HANDLE,
/// \a STD_OUTPUT_HANDLE or \a STD_ERROR_HANDLE. The duplicate's
/// inheritable flag is set to the value of \a inheritable.
///
/// This operation is only available in Win32 systems.
///
/// \pre \a d refers to one of the standard handles as described above.
/// \return A file handle owning a duplicate of the standard handle
///         referred to by \a d.
/// \throw system_error If GetStdHandle() or DuplicateHandle() fail.
///
BOOST_PROCESS_DECL boost::iostreams::file_descriptor
win32_std_fd(unsigned long d, bool inheritable);

/// \brief Changes the file handle's inheritable flag.
///
/// Changes the file handle's inheritable flag to \a i. It is not
/// necessary for the file handle's flag to be different than \a i.
///
/// This operation is only available in Win32 systems.
///
/// \pre The file handle is valid. // FIXME?
/// \post The native file handle's inheritable flag is set to \a i.
/// \throw system_error If the property change fails.
///
BOOST_PROCESS_DECL void
win32_set_inheritable_fd(const boost::iostreams::file_descriptor& fd, bool i);

#endif // #if defined(BOOST_PROCESS_WIN32_API) || defined(BOOST_PROCESS_DOXYGEN)

#if defined(BOOST_PROCESS_POSIX_API) || defined(BOOST_PROCESS_DOXYGEN)

/// \brief Duplicates an open native file handle.
///
/// Given a native file handle \a h1, this routine duplicates it so
/// that it ends up being identified by the native file handle \a h2.
///
/// This operation is only available in POSIX systems.
///
/// \throw system_error If dup2() fails.
///
BOOST_PROCESS_DECL void
posix_dup2_fd(const boost::iostreams::file_descriptor& fd1,
              const boost::iostreams::file_descriptor& fd2);

#endif // #if defined(BOOST_PROCESS_POSIX_API) || defined(BOOST_PROCESS_DOXYGEN)

} // namespace detail
} // namespace process
} // namespace boost

#ifdef BOOST_MSVC
#pragma warning(pop)
#endif

#ifdef BOOST_PROCESS_HEADER_ONLY
#include "boost/process/detail/impl/file_handle.hpp"
#endif

#endif
