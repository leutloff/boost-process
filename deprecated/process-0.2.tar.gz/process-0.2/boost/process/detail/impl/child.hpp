// Boost.Process
//
// Copyright (c) 2006, 2007 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#ifndef BOOST_PROCESS_CHILD_HPP_145715
#define BOOST_PROCESS_CHILD_HPP_145715

#include "boost/process/child.hpp"
#include "boost/process/detail/file_handle.hpp"

namespace boost {
namespace process {

BOOST_PROCESS_INLINE_IF_HEADER_ONLY
const
status child::wait()
{
#if defined(BOOST_PROCESS_POSIX_API)
    int s;
    if (::waitpid(pid_, &s, 0) == -1)
        boost::throw_exception
            (system_error("boost::process::child::wait",
                          "waitpid(2) failed", errno));
    return status(s);
#elif defined(BOOST_PROCESS_WIN32_API)
    DWORD code;
    // XXX This loop should go away in favour of a passive wait.
    do {
        ::GetExitCodeProcess(handle_.get(), &code);
        ::Sleep(500);
    } while (code == STILL_ACTIVE);
    ::WaitForSingleObject(handle_.get(), 0);
    return status(code);
#endif // #elif defined(BOOST_PROCESS_WIN32_API)
}

BOOST_PROCESS_INLINE_IF_HEADER_ONLY
void
child::terminate(bool force) const
{
#if defined(BOOST_PROCESS_POSIX_API)
    if (::kill(pid_, force ? SIGKILL : SIGTERM) == -1)
        boost::throw_exception
            (system_error("boost::process::process::terminate",
                          "kill(2) failed", errno));
#elif defined(BOOST_PROCESS_WIN32_API)
    if (::TerminateProcess(handle_.get(), EXIT_FAILURE) == 0)
        boost::throw_exception
            (system_error("boost::process::process::terminate",
                          "TerminateProcess failed", ::GetLastError()));
#endif
}

#if defined(BOOST_PROCESS_POSIX_API)

BOOST_PROCESS_INLINE_IF_HEADER_ONLY
boost::iostreams::file_descriptor
child::get_input(int desc) const
{
    if (desc == STDIN_FILENO)
        return chin_;
    else {
        file_handle_map::const_iterator iter = input_map_.find(desc);
        BOOST_ASSERT(iter != input_map_.end());
        return iter->second;
    }
}

BOOST_PROCESS_INLINE_IF_HEADER_ONLY
boost::iostreams::file_descriptor
child::get_output(int desc) const
{
    if (desc == STDOUT_FILENO)
        return chout_;
    else if (desc == STDERR_FILENO)
        return cherr_;
    else {
        file_handle_map::const_iterator iter = output_map_.find(desc);
        BOOST_ASSERT(iter != output_map_.end());
        return iter->second;
    }
}

#endif // #if defined(BOOST_PROCESS_POSIX_API)

} // namespace process
} // namespace boost

#endif
