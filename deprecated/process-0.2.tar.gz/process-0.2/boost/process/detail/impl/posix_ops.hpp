// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#ifndef BOOST_PROCESS_POSIX_OPS_HPP_114253
#define BOOST_PROCESS_POSIX_OPS_HPP_114253

#include "boost/process/detail/posix_ops.hpp"
#include "boost/variant/apply_visitor.hpp"
#include "boost/variant/static_visitor.hpp"

namespace boost {
namespace process {
namespace detail {

BOOST_PROCESS_INLINE_IF_HEADER_ONLY
char**
environment_to_envp(const environment& env)
{
    char** ep = new char*[env.size() + 1];
    environment::size_type i = 0;
    for (environment::const_iterator iter = env.begin();
         iter != env.end(); iter++) {
        std::string tmp = iter->first + "=" + iter->second;

        char* cstr = new char[tmp.length() + 1];
        std::strncpy(cstr, tmp.c_str(), tmp.length());
        cstr[tmp.length()] = '\0';

        ep[i++] = cstr;
    }
    ep[i] = 0;
    return ep;
}

struct stream_info_visitor: boost::static_visitor<>
{
    stream_info_visitor(int d,
                        communication_pipes& pipes,
                        bool* closeflags)
    : d_(d)
    , pipes_(pipes)
    , closeflags_(closeflags)
    {
        closeflags[d] = false;
    }

    void operator()(close_stream) const
    {
        closeflags_[d_] = true;
    }

    void operator()(inherit_stream) const
    {}

    void operator()(redirect_stream_to_stdout) const
    {
        // Handled once all other descriptors have been configured.
        // XXX This is most likely a hack begging for problems.
        // Should replace info_map with another collection that
        // respects ordering so that the user can control this.
    }

    void operator()(posix_redirect_stream) const
    {
        // Handled once all other descriptors have been configured.
        // XXX This is most likely a hack begging for problems.
        // Should replace info_map with another collection that
        // respects ordering so that the user can control this.
    }

    void operator()(use_handle sb) const
    {
        if (sb.file_descriptor().handle() != d_)
            posix_dup2_fd(sb.file_descriptor(),
                          boost::iostreams::file_descriptor(d_, false));
    }

protected:
    const int d_;
    communication_pipes& pipes_;
    bool* const closeflags_;
};

struct input_stream_info_visitor: stream_info_visitor
{
    input_stream_info_visitor(int d,
                              communication_pipes& pipes,
                              bool* closeflags)
    : stream_info_visitor(d, pipes, closeflags)
    {}

    using stream_info_visitor::operator();

    void operator()(silence_stream) const
    {
        (*this)(use_file("/dev/zero"));
    }

    void operator()(use_file sb) const
    {
        int fd = ::open(sb.file().c_str(), O_RDONLY);
        if (fd == -1)
            boost::throw_exception
                (system_error("boost::process::detail::setup_input",
                              "open(2) of " + sb.file() + " failed",
                              errno));
        if (fd != d_) {
            boost::iostreams::file_descriptor h(fd, true);
            posix_dup2_fd(h, boost::iostreams::file_descriptor(d_, false));
        }
    }

    void operator()(capture_stream) const
    {
        pipes_[d_].wend().close();
        posix_dup2_fd(pipes_[d_].rend(),
                      boost::iostreams::file_descriptor(d_, false));
    }
};

struct output_stream_info_visitor: stream_info_visitor
{
    output_stream_info_visitor(int d,
                               communication_pipes& pipes,
                               bool* closeflags)
    : stream_info_visitor(d, pipes, closeflags)
    {}

    using stream_info_visitor::operator();

    void operator()(silence_stream) const
    {
        (*this)(use_file("/dev/null"));
    }

    void operator()(use_file sb) const
    {
        int fd = ::open(sb.file().c_str(), O_WRONLY);
        if (fd == -1)
            boost::throw_exception
                (system_error("boost::process::detail::setup_output",
                              "open(2) of " + sb.file() + " failed",
                              errno));
        if (fd != d_) {
            boost::iostreams::file_descriptor h(fd, true);
            posix_dup2_fd(h, boost::iostreams::file_descriptor(d_, false));
        }
    }

    void operator()(capture_stream) const
    {
        pipes_[d_].rend().close();
        posix_dup2_fd(pipes_[d_].wend(),
                      boost::iostreams::file_descriptor(d_, false));
    }
};

BOOST_PROCESS_INLINE_IF_HEADER_ONLY
void
setup_input(const behavior_map& bm,
            communication_pipes& input_pipes,
            bool* closeflags,
            int maxdescs)
{
    for (behavior_map::const_iterator it = bm.begin(); it != bm.end(); ++it) {
        BOOST_ASSERT(it->first < maxdescs);
        closeflags[it->first] = false;
        boost::apply_visitor(
            input_stream_info_visitor(it->first, input_pipes, closeflags),
            it->second);
    }
}

BOOST_PROCESS_INLINE_IF_HEADER_ONLY
void
setup_output(const behavior_map& bm,
             communication_pipes& output_pipes,
             bool* closeflags,
             int maxdescs)
{
    for (behavior_map::const_iterator it = bm.begin(); it != bm.end(); it++) {
        BOOST_ASSERT(it->first < maxdescs);
        closeflags[it->first] = false;
        boost::apply_visitor(
            output_stream_info_visitor(it->first, output_pipes, closeflags),
            it->second);
    }
    for (behavior_map::const_iterator it = bm.begin(); it != bm.end(); ++it) {
        if (boost::get<redirect_stream_to_stdout>(&it->second))
            posix_dup2_fd(
                boost::iostreams::file_descriptor(STDOUT_FILENO, false),
                boost::iostreams::file_descriptor(it->first, false));
        if (const posix_redirect_stream* rs =
                boost::get<posix_redirect_stream>(&it->second))
            posix_dup2_fd(
                boost::iostreams::file_descriptor(rs->desc_to(), false),
                boost::iostreams::file_descriptor(it->first, false));
    }
}

} // namespace detail
} // namespace process
} // namespace boost

#endif
