// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#ifndef BOOST_PROCESS_ENVIRONMENT_HPP_115014
#define BOOST_PROCESS_ENVIRONMENT_HPP_115014

#include "boost/process/environment.hpp"

#if defined(BOOST_PROCESS_POSIX_API)
extern "C" {
    extern char** environ;
}
#endif

namespace boost {
namespace process {

BOOST_PROCESS_INLINE_IF_HEADER_ONLY
environment
current_environment()
{
    environment env;

#if defined(BOOST_PROCESS_POSIX_API)
    char** ptr = ::environ;
    while (*ptr != 0) {
        std::string str = *ptr;
        std::string::size_type pos = str.find('=');
        env.insert
            (environment::value_type(str.substr(0, pos),
                                     str.substr(pos + 1, str.length())));
        ptr++;
    }
#elif defined(BOOST_PROCESS_WIN32_API)
    TCHAR* es = ::GetEnvironmentStrings();
    if (es == 0)
        boost::throw_exception
            (system_error("boost::process::current_environment",
                          "GetEnvironmentStrings failed", ::GetLastError()));

    try {
        TCHAR* escp = es;
        while (*escp != '\0') {
            std::string str = escp;
            std::string::size_type pos = str.find('=');
            env.insert
                (environment::value_type(str.substr(0, pos),
                                         str.substr(pos + 1, str.length())));
            escp += str.length() + 1;
        }
    } catch (...) {
        ::FreeEnvironmentStrings(es);
        throw;
    }

    ::FreeEnvironmentStrings(es);
#endif

    return env;
}

} // namespace process
} // namespace boost

#endif
