// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#ifndef BOOST_PROCESS_PIPE_HPP_114312
#define BOOST_PROCESS_PIPE_HPP_114312

#include "boost/process/detail/pipe.hpp"
#include "boost/process/exceptions.hpp"
#include "boost/throw_exception.hpp"
#if defined(BOOST_PROCESS_POSIX_API)
    #include <unistd.h>
    #include <cerrno>
#elif defined(BOOST_PROCESS_WIN32_API)
    #define WIN32_LEAN_AND_MEAN
    #include <windows.h>
#else
    #error "Unsupported platform."
#endif

namespace boost {
namespace process {
namespace detail {

BOOST_PROCESS_INLINE_IF_HEADER_ONLY
pipe::pipe()
{
    boost::iostreams::file_descriptor::handle_type hs[2];

#if defined(BOOST_PROCESS_WIN32_API)
    SECURITY_ATTRIBUTES sa;
    ZeroMemory(&sa, sizeof(sa));
    sa.nLength = sizeof(sa);
    sa.lpSecurityDescriptor = 0;
    sa.bInheritHandle = FALSE;

    if (!::CreatePipe(&hs[0], &hs[1], &sa, 0))
        boost::throw_exception
            (system_error("boost::process::detail::pipe::pipe",
                          "CreatePipe failed", ::GetLastError()));
#else
    if (::pipe(hs) == -1)
        boost::throw_exception
            (system_error("boost::process::detail::pipe::pipe",
                          "pipe(2) failed", errno));
#endif

    read_end_ = boost::iostreams::file_descriptor(hs[0], true);
    write_end_ = boost::iostreams::file_descriptor(hs[1], true);
}

} // namespace detail
} // namespace process
} // namespace boost

#endif
