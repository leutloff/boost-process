// Boost.Process
// Tests for the posix::child class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "boost/process/config.hpp"

#if defined(BOOST_PROCESS_POSIX_API)

#include "child.hpp"
#include "util/unit_test_main.hpp"
#include "boost/process/child.hpp"
#include "boost/test/unit_test.hpp"

namespace bp = boost::process;
namespace bpd = boost::process::detail;
namespace bios = boost::iostreams;
namespace butf = boost::unit_test::framework;

namespace {

struct posix_launcher
{
    bp::child
    operator()(bp::child::native_type native) const
    {
        return bp::child(native,
                          bp::child::file_handle_map(),
                          bp::child::file_handle_map());
    }

    bp::child
    operator()(bp::child::native_type native,
               bios::file_descriptor stdinfh,
               bios::file_descriptor stdoutfh,
               bios::file_descriptor stderrfh) const
    {
        bp::child::file_handle_map im;
        if (bpd::is_valid_fd(stdinfh))
            im.insert(std::make_pair(STDIN_FILENO, stdinfh));

        bp::child::file_handle_map om;
        if (bpd::is_valid_fd(stdoutfh))
            om.insert(std::make_pair(STDOUT_FILENO, stdoutfh));
        if (bpd::is_valid_fd(stderrfh))
            om.insert(std::make_pair(STDERR_FILENO, stderrfh));

        return bp::child(native, im, om);
    }
};

} // namespace {

bool init_unit_test()
{
    child_tests::add<bp::child, posix_launcher>(butf::master_test_suite());
    return true;
}

#else // #if defined(BOOST_PROCESS_POSIX_API)

int main() { return 0; }

#endif // #if defined(BOOST_PROCESS_POSIX_API)
