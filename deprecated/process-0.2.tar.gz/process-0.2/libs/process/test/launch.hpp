// Boost.Process
// Tests for Launcher implementations.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#ifndef BOOST_PROCESS_LAUNCH_HPP_173505
#define BOOST_PROCESS_LAUNCH_HPP_173505

#include "util/use_helpers.hpp"
#include "boost/process/environment.hpp"
#include "boost/process/status.hpp"
#include "boost/process/stream_behavior.hpp"
#include "boost/iostreams/stream.hpp"
#include "boost/test/unit_test.hpp"
#include <string>
#include <utility>

namespace launch_tests {

namespace bfs = boost::filesystem;
namespace bp = boost::process;
namespace bios = boost::iostreams;
namespace but = boost::unit_test;

// Overview
// --------
//
// The functions below implement tests for common launcher functionality.
// These are used to test different implementations without duplicating
// much code.
//
// Launcher concept
// ----------------
//
// The functions in this file all rely on a Launcher concept. This concept
// provides a class whose () operator starts a new process given an
// executable, its arguments, an execution context and the redirections for
// the standard streams, and returns a new Child object. The operator also
// receives a boolean, defaulting to false, that indicates if the child
// process focuses on testing stdin input. This is needed when testing
// pipelines to properly place a dummy process in the flow.
//
// I know this is ugly but allows reusing all tests to check various
// different launchers. A nicer approach might be attempted later on.

template<class Launcher, class Context, class Child>
void test_close_stdin()
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("is-closed-stdin");

    const bp::status s1 = Launcher()(args, Context(), bp::close_stream(),
                                     bp::close_stream(), bp::close_stream(),
                                     true).wait();
    BOOST_REQUIRE(s1.exited());
    BOOST_CHECK_EQUAL(s1.exit_status(), EXIT_SUCCESS);
}

template<class Launcher, class Context, class Child>
void test_close_stdout()
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("is-closed-stdout");

    const bp::status s1 = Launcher()(args, Context()).wait();
    BOOST_REQUIRE(s1.exited());
    BOOST_CHECK_EQUAL(s1.exit_status(), EXIT_SUCCESS);
}

template<class Launcher, class Context, class Child>
void test_close_stderr()
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("is-closed-stderr");

    const bp::status s1 = Launcher()(args, Context()).wait();
    BOOST_REQUIRE(s1.exited());
    BOOST_CHECK_EQUAL(s1.exit_status(), EXIT_SUCCESS);
}

template<class Launcher, class Context, class Child>
void test_input()
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("stdin-to-stdout");

    Child c = Launcher()(args, Context(), bp::capture_stream(),
                         bp::capture_stream());

    bios::stream<bios::file_descriptor> os(c.get_stdin());
    os << "message";
    os.close();
    bios::stream<bios::file_descriptor> is(c.get_stdout());
    std::string word;
    is >> word;
    BOOST_CHECK_EQUAL(word, "message");

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

template<class Launcher, class Context, class Child>
void test_output(bool out, const std::string& msg)
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back(out ? "echo-stdout" : "echo-stderr");
    args.push_back(msg);

    Child c = Launcher()(args, Context(), bp::close_stream(),
                         out ? bp::stream_behavior(bp::capture_stream())
                             : bp::stream_behavior(bp::close_stream()),
                         out ? bp::stream_behavior(bp::close_stream())
                             : bp::stream_behavior(bp::capture_stream()));

    bios::file_descriptor fd = out ? c.get_stdout() : c.get_stderr();
    char word[32]; // FIXME
    std::streamsize ss = fd.read(word, sizeof(word)-1);
    BOOST_REQUIRE(ss > 0);
    word[ss] = 0;
    BOOST_CHECK_EQUAL(word, msg);

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

template<class Launcher, class Context, class Child>
void test_stderr()
{
    test_output<Launcher, Context, Child>(false, "message1-stderr");
    test_output<Launcher, Context, Child>(false, "message2-stderr");
}

template<class Launcher, class Context, class Child>
void test_stdout()
{
    test_output<Launcher, Context, Child>(true, "message1-stdout");
    test_output<Launcher, Context, Child>(true, "message2-stdout");
}

template<class Launcher, class Context, class Child>
void test_redirect_err_to_out()
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("echo-stdout-stderr");
    args.push_back("message-to-two-streams");

    Child c = Launcher()(args, Context(), bp::close_stream(),
                         bp::capture_stream(),
                         bp::redirect_stream_to_stdout());

    bios::stream<bios::file_descriptor> is(c.get_stdout());
    std::string word;
    is >> word;
    BOOST_CHECK_EQUAL(word, "stdout");
    is >> word;
    BOOST_CHECK_EQUAL(word, "message-to-two-streams");
    is >> word;
    BOOST_CHECK_EQUAL(word, "stderr");
    is >> word;
    BOOST_CHECK_EQUAL(word, "message-to-two-streams");

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

template<class Launcher, class Context, class Child>
void check_work_directory(const std::string& wdir)
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("pwd");

    Context ctx;
    if (wdir.empty())
        BOOST_CHECK_MESSAGE(
            bfs::equivalent(ctx.work_directory, bfs::current_path().string()),
            "check failed, '" << ctx.work_directory << "', '"
                              << bfs::current_path() << "'"
        );
    else
        ctx.work_directory = wdir;
    Child c = Launcher()(args, ctx, bp::close_stream(),
                         bp::capture_stream());

    bios::stream<bios::file_descriptor> is(c.get_stdout());
    std::string dir;
    std::getline(is, dir);

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_REQUIRE_EQUAL(s.exit_status(), EXIT_SUCCESS);

    BOOST_CHECK_EQUAL(bfs::path(dir), bfs::path(ctx.work_directory));
}

template<class Launcher, class Context, class Child>
void test_work_directory()
{
    check_work_directory<Launcher, Context, Child>("");

    bfs::path wdir = bfs::current_path() / "test.dir";
    BOOST_REQUIRE_NO_THROW(bfs::create_directory(wdir));
    try {
        check_work_directory<Launcher, Context, Child>(wdir.string());
        BOOST_CHECK_NO_THROW(bfs::remove_all(wdir));
    } catch(...) {
        BOOST_CHECK_NO_THROW(bfs::remove_all(wdir));
        throw;
    }
}

template<class Launcher, class Context, class Child>
std::string
get_var_value(Context& ctx, const std::string& var)
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("query-env");
    args.push_back(var);

    Child c = Launcher()(args, ctx, bp::close_stream(),
                         bp::capture_stream());

    bios::stream<bios::file_descriptor> is(c.get_stdout());
    std::string value;
    is >> value;

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_REQUIRE_EQUAL(s.exit_status(), EXIT_SUCCESS);

    return value;
}

template<class Launcher, class Context, class Child>
void test_clear_environment()
{
#if defined(BOOST_PROCESS_POSIX_API)
    BOOST_REQUIRE(::setenv("TO_BE_QUERIED", "test", 1) != -1);
    BOOST_REQUIRE(::getenv("TO_BE_QUERIED") != 0);
#elif defined(BOOST_PROCESS_WIN32_API)
    BOOST_REQUIRE(::SetEnvironmentVariable("TO_BE_QUERIED", "test") != 0);
    TCHAR buf[5];
    BOOST_REQUIRE(::GetEnvironmentVariable("TO_BE_QUERIED", buf, 5) != 0);
#endif

    Context ctx;
    BOOST_REQUIRE_EQUAL(ctx.environment.size(),
                        (bp::environment::size_type)0);

    std::string p1(
        get_var_value<Launcher, Context, Child>(ctx, "TO_BE_QUERIED"));
    BOOST_CHECK(!p1.empty());
    BOOST_CHECK(p1 != "undefined");

    std::string p2(get_var_value<Launcher, Context, Child>(ctx, "PATH"));
    BOOST_CHECK(!p2.empty());
    BOOST_CHECK(p2 != "undefined");

    std::string p3(get_var_value<Launcher, Context, Child>(ctx, "HOME"));
    BOOST_CHECK(!p3.empty());
    BOOST_CHECK(p3 != "undefined");
}

template<class Launcher, class Context, class Child>
void test_unset_environment()
{
#if defined(BOOST_PROCESS_POSIX_API)
    BOOST_REQUIRE(::setenv("TO_BE_UNSET", "test", 1) != -1);
    BOOST_REQUIRE(::getenv("TO_BE_UNSET") != 0);
#elif defined(BOOST_PROCESS_WIN32_API)
    BOOST_REQUIRE(::SetEnvironmentVariable("TO_BE_UNSET", "test") != 0);
    TCHAR buf[5];
    BOOST_REQUIRE(::GetEnvironmentVariable("TO_BE_UNSET", buf, 5) != 0);
#endif

    Context ctx;
    ctx.environment = bp::current_environment();
    ctx.environment.erase("TO_BE_UNSET");
    std::string p(get_var_value<Launcher, Context, Child>(ctx, "TO_BE_UNSET"));
    BOOST_CHECK_EQUAL(p, "undefined");
}

template<class Launcher, class Context, class Child>
void test_set_environment_var(const std::string& value)
{
#if defined(BOOST_PROCESS_POSIX_API)
    ::unsetenv("TO_BE_SET");
    BOOST_REQUIRE(::getenv("TO_BE_SET") == 0);
#elif defined(BOOST_PROCESS_WIN32_API)
    TCHAR buf[5];
    BOOST_REQUIRE(::GetEnvironmentVariable("TO_BE_SET", buf, 0) == 0 ||
                  ::SetEnvironmentVariable("TO_BE_SET", 0) != 0);
    BOOST_REQUIRE(::GetEnvironmentVariable("TO_BE_SET", buf, 5) == 0);
#endif

    Context ctx;
    ctx.environment.insert(bp::environment::value_type("TO_BE_SET", value));
    std::string p(get_var_value<Launcher, Context, Child>(ctx, "TO_BE_SET"));
    BOOST_CHECK_EQUAL(p, value);
}

template<class Launcher, class Context, class Child>
void test_set_environment()
{
#if defined(BOOST_PROCESS_POSIX_API)
    test_set_environment_var<Launcher, Context, Child>("");
#endif
    test_set_environment_var<Launcher, Context, Child>("some-value-1");
    test_set_environment_var<Launcher, Context, Child>("some-value-2");
}

template<class Launcher, class Context, class Child>
void add(but::test_suite& ts)
{
    ts.add(BOOST_TEST_CASE
        ((&test_close_stdin<Launcher, Context, Child>)), 0, 10);
    ts.add(BOOST_TEST_CASE
        ((&test_close_stdout<Launcher, Context, Child>)), 0, 10);
    ts.add(BOOST_TEST_CASE
        ((&test_close_stderr<Launcher, Context, Child>)), 0, 10);
    ts.add(BOOST_TEST_CASE
        ((&test_stdout<Launcher, Context, Child>)), 0, 10);
    ts.add(BOOST_TEST_CASE
        ((&test_stderr<Launcher, Context, Child>)), 0, 10);
    ts.add(BOOST_TEST_CASE
        ((&test_redirect_err_to_out<Launcher, Context, Child>)), 0, 10);
    ts.add(BOOST_TEST_CASE
        ((&test_input<Launcher, Context, Child>)), 0, 10);
    ts.add(BOOST_TEST_CASE
        ((&test_work_directory<Launcher, Context, Child>)), 0, 10);
    ts.add(BOOST_TEST_CASE
        ((&test_unset_environment<Launcher, Context, Child>)), 0, 10);
    ts.add(BOOST_TEST_CASE
        ((&test_set_environment<Launcher, Context, Child>)), 0, 10);

// enable this test only if helpers.exe links with static runtime library,
// otherwise it will fail to find runtime dll;
// '#if' below works only if you compile this file
// with the same settings as helpers.exe
//#if defined(BOOST_MSVC) && !defined(_DLL)
//    ts.add(BOOST_TEST_CASE
//        ((&test_clear_environment<Launcher, Context, Child>)), 0, 10);
//#endif
}

} // namespace launch_tests {

#endif
