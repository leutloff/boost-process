// Boost.Process
// Tests for the launcher class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "launch.hpp"
#include "util/unit_test_main.hpp"
#include "util/use_helpers.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/operations.hpp"
#include "boost/filesystem/operations.hpp"
#include "boost/test/unit_test.hpp"

namespace bp = boost::process;
namespace butf = boost::unit_test::framework;

namespace {

struct launcher
{
    bp::child
    operator()(const std::vector<std::string> args, bp::context ctx,
               bp::stream_behavior bstdin = bp::close_stream(),
               bp::stream_behavior bstdout = bp::close_stream(),
               bp::stream_behavior bstderr = bp::close_stream(),
               bool usein = false) const
    {
#if defined(BOOST_PROCESS_WIN32_API)
        ctx.stdin_behavior = bstdin;
        ctx.stdout_behavior = bstdout;
        ctx.stderr_behavior = bstderr;
#elif defined(BOOST_PROCESS_POSIX_API)
        ctx.input_behavior.insert(std::make_pair(STDIN_FILENO, bstdin));
        ctx.output_behavior.insert(std::make_pair(STDOUT_FILENO, bstdout));
        ctx.output_behavior.insert(std::make_pair(STDERR_FILENO, bstderr));
#endif // #elif defined(BOOST_PROCESS_POSIX_API)
        return bp::launch(get_helpers_path(), args, ctx);
    }
};

} // namespace {

bool init_unit_test()
{
    check_helpers();
    launch_tests::add<launcher, bp::context, bp::child>
        (butf::master_test_suite());
    return true;
}
