// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#ifndef BOOST_PROCESS_USE_HELPERS_HPP_173325
#define BOOST_PROCESS_USE_HELPERS_HPP_173325

#include "boost/filesystem/operations.hpp"
#include "boost/filesystem/path.hpp"
#include "boost/test/unit_test.hpp"

#include <istream>
#include <string>

namespace bfs = boost::filesystem;
namespace but = boost::unit_test;
namespace butf = boost::unit_test::framework;

inline const std::string& get_helpers_path()
{
    static const std::string hp =
        (bfs::initial_path() / butf::master_test_suite().argv[1]).string();
    return hp;
}

inline void check_helpers()
{
    if (butf::master_test_suite().argc != 2)
        throw butf::setup_error("path to helper expected");
    if (!bfs::exists(get_helpers_path()))
        throw butf::setup_error(
            "helper's path '" + get_helpers_path() + "' does not exists");
}

#endif
