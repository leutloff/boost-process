// copypaste'd boost/1.34.1/boost/test/unit_test.hpp:main() function
// Copyright 2001-2005 Gennadiy Rozental
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#ifndef BOOST_PROCESS_UNIT_TEST_MAIN_HPP_173347
#define BOOST_PROCESS_UNIT_TEST_MAIN_HPP_173347

#ifdef BOOST_TEST_DYN_LINK

#include "boost/test/unit_test.hpp"

// extern specifier is for documentation purposes only
// this function should be defined somethere
extern bool init_unit_test();

int BOOST_TEST_CALL_DECL main(int argc, char* argv[])
{
    return boost::unit_test::unit_test_main(init_unit_test, argc, argv);
}

#endif // #ifdef BOOST_TEST_DYN_LINK

#endif
