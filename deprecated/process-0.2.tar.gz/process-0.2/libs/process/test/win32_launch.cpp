// Boost.Process
// Tests for the win32::launch method and win32::context class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "boost/process/config.hpp"

#if defined(BOOST_PROCESS_WIN32_API)

#include "launch.hpp"
#include "util/use_helpers.hpp"
#include "util/unit_test_main.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/operations.hpp"
#include "boost/iostreams/filtering_stream.hpp"
#include "boost/iostreams/filter/newline.hpp"
#include "boost/test/unit_test.hpp"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <sstream>
#include <string>

namespace bp = boost::process;
namespace bios = boost::iostreams;
namespace butf = boost::unit_test::framework;

namespace {

struct launcher
{
    bp::child
    operator()(const std::vector<std::string> args,
               bp::context ctx,
               bp::stream_behavior bstdin = bp::close_stream(),
               bp::stream_behavior bstdout = bp::close_stream(),
               bp::stream_behavior bstderr = bp::close_stream(),
               bool usein = false) const
    {
        ctx.stdin_behavior = bstdin;
        ctx.stdout_behavior = bstdout;
        ctx.stderr_behavior = bstderr;
        return bp::launch(get_helpers_path(), args, ctx);
    }
};

template<class Child>
void test_startupinfo()
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("win32-print-startupinfo");

    std::string line;
    std::ostringstream flags;

    bp::context ctx1;
    ctx1.stdout_behavior = bp::capture_stream();
    flags << STARTF_USESTDHANDLES;
    Child c1 = bp::launch(get_helpers_path(), args, ctx1);

    bios::filtering_istream is;
    is.push(bios::newline_filter(bios::newline::posix));
    is.push(c1.get_stdout());
    std::getline(is, line);
    BOOST_CHECK_EQUAL(line, "dwFlags = " + flags.str());
    flags.str("");
    std::getline(is, line);
    BOOST_CHECK_EQUAL(line, "dwX = 0");
    std::getline(is, line);
    BOOST_CHECK_EQUAL(line, "dwY = 0");
    std::getline(is, line);
    BOOST_CHECK_EQUAL(line, "dwXSize = 0");
    std::getline(is, line);
    BOOST_CHECK_EQUAL(line, "dwYSize = 0");
    const bp::status s1 = c1.wait();
    BOOST_REQUIRE(s1.exited());
    BOOST_CHECK_EQUAL(s1.exit_status(), EXIT_SUCCESS);

    STARTUPINFO si;
    ::ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USEPOSITION | STARTF_USESIZE;
    si.dwX = 100;
    si.dwY = 200;
    si.dwXSize = 300;
    si.dwYSize = 400;
    bp::context ctx2;
    ctx2.startupinfo = &si;
    ctx2.stdout_behavior = bp::capture_stream();
    flags << (STARTF_USESTDHANDLES | STARTF_USEPOSITION | STARTF_USESIZE);
    Child c2 = bp::launch(get_helpers_path(), args, ctx2);
    is.reset();
    is.push(bios::newline_filter(bios::newline::posix));
    is.push(c2.get_stdout());
    std::getline(is, line);
    BOOST_CHECK_EQUAL(line, "dwFlags = " + flags.str());
    flags.str("");
    std::getline(is, line);
    BOOST_CHECK_EQUAL(line, "dwX = 100");
    std::getline(is, line);
    BOOST_CHECK_EQUAL(line, "dwY = 200");
    std::getline(is, line);
    BOOST_CHECK_EQUAL(line, "dwXSize = 300");
    std::getline(is, line);
    BOOST_CHECK_EQUAL(line, "dwYSize = 400");
    const bp::status s2 = c2.wait();
    BOOST_REQUIRE(s2.exited());
    BOOST_CHECK_EQUAL(s2.exit_status(), EXIT_SUCCESS);
}

} // namespace {

bool init_unit_test()
{
    check_helpers();
    launch_tests::add<launcher, bp::context, bp::child>
        (butf::master_test_suite());
// FIXME
//    butf::master_test_suite()
//        .add(BOOST_TEST_CASE(&test_startupinfo<bp::child>));
    return true;
}

#else // #if defined(BOOST_PROCESS_WIN32_API)

int main() { return 0; }

#endif // #if defined(BOOST_PROCESS_WIN32_API)
