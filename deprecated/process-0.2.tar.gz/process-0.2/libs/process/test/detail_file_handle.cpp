// Boost.Process
// Tests for the detail::file_handle class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "boost/process/detail/file_handle.hpp"
#include "boost/test/unit_test.hpp"
#if defined(BOOST_PROCESS_POSIX_API)
    #include <unistd.h>
    #include <cstdlib>
    #include <cstring>
#elif defined(BOOST_PROCESS_WIN32_API)
    #define WIN32_LEAN_AND_MEAN
    #include <windows.h>
#else
    #error "Unsupported platform."
#endif
#include <iostream>

namespace bp = boost::process;
namespace bpd = boost::process::detail;
namespace bios = boost::iostreams;
namespace butf = boost::unit_test::framework;

namespace {

#if defined(BOOST_PROCESS_WIN32_API)

void test_win32_dup_fd()
{
    HANDLE in, out;
    SECURITY_ATTRIBUTES sa;
    ZeroMemory(&sa, sizeof(sa));
    sa.nLength = sizeof(sa);
    sa.lpSecurityDescriptor = 0;
    sa.bInheritHandle = FALSE;
    BOOST_REQUIRE(::CreatePipe(&in, &out, &sa, 0) != 0);
    bios::file_descriptor rend(in, true);
    bios::file_descriptor wend(out, true);

    DWORD flags, rcnt;
    char buf[15];

    bios::file_descriptor out2(bpd::win32_dup_fd(wend, false));
    BOOST_REQUIRE(::GetHandleInformation(out2.handle(), &flags) != 0);
    BOOST_REQUIRE(!(flags & HANDLE_FLAG_INHERIT));

    bios::file_descriptor out3(bpd::win32_dup_fd(wend, true));
    BOOST_REQUIRE(::GetHandleInformation(out3.handle(), &flags) != 0);
    BOOST_REQUIRE(flags & HANDLE_FLAG_INHERIT);

    BOOST_REQUIRE(::WriteFile(wend.handle(), "test-win32-dup", 14, &rcnt,
                              0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 14);
    BOOST_REQUIRE(::ReadFile(rend.handle(), buf, sizeof(buf), &rcnt, 0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 14);
    buf[14] = '\0';
    BOOST_REQUIRE(std::strcmp(buf, "test-win32-dup") == 0);

    BOOST_REQUIRE(::WriteFile(out2.handle(), "test-win32-dup", 14, &rcnt,
                              0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 14);
    BOOST_REQUIRE(::ReadFile(rend.handle(), buf, sizeof(buf), &rcnt, 0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 14);
    buf[14] = '\0';
    BOOST_REQUIRE(std::strcmp(buf, "test-win32-dup") == 0);

    BOOST_REQUIRE(::WriteFile(out3.handle(), "test-win32-dup", 14, &rcnt,
                              0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 14);
    BOOST_REQUIRE(::ReadFile(rend.handle(), buf, sizeof(buf), &rcnt, 0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 14);
    buf[14] = '\0';
    BOOST_REQUIRE(std::strcmp(buf, "test-win32-dup") == 0);
}

void test_win32_set_inheritable_fd()
{
    HANDLE in, out;
    SECURITY_ATTRIBUTES sa;
    ZeroMemory(&sa, sizeof(sa));
    sa.nLength = sizeof(sa);
    sa.lpSecurityDescriptor = 0;
    sa.bInheritHandle = FALSE;
    BOOST_REQUIRE(::CreatePipe(&in, &out, &sa, 0) != 0);
    bios::file_descriptor rend(in, true);
    bios::file_descriptor wend(out, true);

    DWORD flags;

    bios::file_descriptor out2(bpd::win32_dup_fd(wend, false));
    BOOST_REQUIRE(::GetHandleInformation(out2.handle(), &flags) != 0);
    BOOST_REQUIRE(!(flags & HANDLE_FLAG_INHERIT));

    bios::file_descriptor out3(bpd::win32_dup_fd(wend, true));
    BOOST_REQUIRE(::GetHandleInformation(out3.handle(), &flags) != 0);
    BOOST_REQUIRE(flags & HANDLE_FLAG_INHERIT);
}

#endif // #if defined(BOOST_PROCESS_WIN32_API)

#if defined(BOOST_PROCESS_POSIX_API)

void test_posix_dup2_fd()
{
    int pfd[2];

    BOOST_REQUIRE(::pipe(pfd) != -1);
    bios::file_descriptor rend(pfd[0], true);
    bios::file_descriptor wend(pfd[1], true);

    BOOST_REQUIRE(rend.handle() != 10);
    BOOST_REQUIRE(wend.handle() != 10);
    bios::file_descriptor fh1(10, true);
    bpd::posix_dup2_fd(wend, fh1);

    BOOST_REQUIRE(::write(wend.handle(), "test-posix-dup", 14) != -1);
    char buf1[15];
    BOOST_REQUIRE_EQUAL(::read(rend.handle(), buf1, sizeof(buf1)), 14);
    buf1[14] = '\0';
    BOOST_REQUIRE(std::strcmp(buf1, "test-posix-dup") == 0);

    BOOST_REQUIRE(::write(fh1.handle(), "test-posix-dup", 14) != -1);
    char buf2[15];
    BOOST_REQUIRE_EQUAL(::read(rend.handle(), buf2, sizeof(buf2)), 14);
    buf2[14] = '\0';
    BOOST_REQUIRE(std::strcmp(buf2, "test-posix-dup") == 0);
}

#endif // #if defined(BOOST_PROCESS_POSIX_API)

} // namespace {

bool init_unit_test()
{
#if defined(BOOST_PROCESS_WIN32_API)
    butf::master_test_suite().add(BOOST_TEST_CASE(
        test_win32_dup_fd));
    butf::master_test_suite().add(BOOST_TEST_CASE(
        test_win32_set_inheritable_fd));
#elif defined(BOOST_PROCESS_POSIX_API)
    butf::master_test_suite().add(BOOST_TEST_CASE(test_posix_dup2_fd));
#endif
    return true;
}
