// Boost.Process
// Tests for Child implementations.
//
// Copyright (c) 2006, 2007 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#ifndef BOOST_PROCESS_CHILD_HPP_173522
#define BOOST_PROCESS_CHILD_HPP_173522

#include "util/use_helpers.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/detail/pipe.hpp"
#include "boost/process/operations.hpp"
#include "boost/test/unit_test.hpp"

namespace child_tests {

namespace bp = boost::process;
namespace bpd = boost::process::detail;
namespace bios = boost::iostreams;
namespace but = boost::unit_test;

// Overview
// --------
//
// The functions below implement tests for the basic Child implementation.
// In order to ensure appropriate behavior, all implementations must
// have the same behavior in common public methods; keeping this set of
// tests generic makes it easy to check this restriction because the tests
// can easily be applied to any specific Child implementation.
//
// Factory concept
// ---------------
//
// The functions in this file all rely on a Factory concept. This concept
// provides a class whose operator() constructs a new Child instance
// based on a process's identifier and three file handles, one for each of
// the standard communication channels. Note that this is the most possible
// generic construction, which should be conceptually supported by all
// implementations.

template<class Child, class Factory>
void test_getters()
{
    typedef bios::file_descriptor::handle_type ht;
    bios::file_descriptor in (reinterpret_cast<ht>(101), false);
    bios::file_descriptor out(reinterpret_cast<ht>(105), false);
    bios::file_descriptor err(reinterpret_cast<ht>(107), false);
    Child c = Factory()(0, in, out, err);
    BOOST_CHECK_EQUAL(c.get_stdin().handle(),  in.handle());
    BOOST_CHECK_EQUAL(c.get_stdout().handle(), out.handle());
    BOOST_CHECK_EQUAL(c.get_stderr().handle(), err.handle());
}

template<class Process, class Factory>
void test_terminate()
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("loop");

    bp::context ctx;
    bp::child c = bp::launch(get_helpers_path(), args, ctx);

    c.terminate();

    bp::status s = c.wait();
#if defined(BOOST_PROCESS_POSIX_API)
    BOOST_REQUIRE(!s.exited());
    BOOST_REQUIRE(s.signaled());
#elif defined(BOOST_PROCESS_WIN32_API)
    BOOST_REQUIRE(s.exited());
    // XXX According to the way we use TerminateProcess we should get an
    // EXIT_FAILURE here, but we don't...
    //BOOST_REQUIRE_EQUAL(s.exit_status(), EXIT_FAILURE);
#endif
}

template<class Child, class Factory>
void add(but::test_suite& ts)
{
    ts.add(BOOST_TEST_CASE((&test_getters<Child, Factory>)));
    ts.add(BOOST_TEST_CASE((&test_terminate<Child, Factory>)));
}

} // namespace child_tests

#endif
