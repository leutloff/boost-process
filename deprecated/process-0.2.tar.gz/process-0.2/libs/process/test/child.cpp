// Boost.Process
// Tests for the child class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "child.hpp"
#include "util/unit_test_main.hpp"
#include "util/use_helpers.hpp"
#include "boost/process/child.hpp"
#include "boost/process/process.hpp"
#include "boost/test/unit_test.hpp"

namespace bp = boost::process;
namespace bpd = boost::process::detail;
namespace bios = boost::iostreams;
namespace butf = boost::unit_test::framework;

namespace {

struct launcher
{
    bp::child
    operator()(bp::child::native_type native) const
    {
        bios::file_descriptor invalidfh;
        return bp::child(native, invalidfh, invalidfh, invalidfh);
    }

    bp::child
    operator()(bp::child::native_type native,
               bios::file_descriptor stdinfh,
               bios::file_descriptor stdoutfh,
               bios::file_descriptor stderrfh) const
    {
        return bp::child(native, stdinfh, stdoutfh, stderrfh);
    }
};

} // namespace {

bool init_unit_test()
{
    check_helpers();
    child_tests::add<bp::child, launcher>(butf::master_test_suite());
    return true;
}
