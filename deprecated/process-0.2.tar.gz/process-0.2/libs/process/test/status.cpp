// Boost.Process
// Tests for the status class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/use_helpers.hpp"
#include "util/unit_test_main.hpp"
#include "boost/process/launch.hpp"
#include "boost/process/status.hpp"
#include "boost/test/unit_test.hpp"

namespace bp = boost::processes;
namespace butf = boost::unit_test::framework;

namespace {

bp::status launch_helper(const std::string& name)
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back(name);
    return bp::launch(get_helpers_path(), args, bp::context()).wait();
}

/*
void test_exit_failure()
{
    const bp::status s = launch_helper("exit-failure");
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_FAILURE);
}
*/

void test_exit_success()
{
    const bp::status s = launch_helper("exit-success");
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

} // namespace {

bool init_unit_test()
{
    check_helpers();
    butf::master_test_suite().add(BOOST_TEST_CASE(&test_exit_success), 0, 10);
//    butf::master_test_suite().add(BOOST_TEST_CASE(&test_exit_failure), 0, 10);
    return true;
}
