// Boost.Process
// Check that the library compiles with BOOST_USE_WINDOWS_H #defined.
//
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "boost/process/config.hpp"

#ifdef BOOST_WINDOWS_API

#ifndef BOOST_USE_WINDOWS_H
#error BOOST_USE_WINDOWS_H must be defined for this test
#endif

#ifndef BOOST_PROCESS_HEADER_ONLY
#error BOOST_PROCESS_HEADER_ONLY must be defined for this test
#endif

#include "boost/process.hpp"

#else // #ifdef BOOST_WINDOWS_API

int main() { return 0; }

#endif // #else // #ifdef BOOST_WINDOWS_API
