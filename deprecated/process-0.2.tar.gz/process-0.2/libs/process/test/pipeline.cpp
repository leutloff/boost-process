// Boost.Process
// Tests for the launcher class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "launch.hpp"
#include "util/use_helpers.hpp"
#include "util/unit_test_main.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/operations.hpp"
#include "boost/filesystem/operations.hpp"
#include "boost/iostreams/stream.hpp"
#include "boost/test/unit_test.hpp"
#include <cstring>

namespace bp = boost::process;
namespace bios = boost::iostreams;
namespace butf = boost::unit_test::framework;

namespace {

class children_to_child
{
    bp::children cs_;

public:
    children_to_child(bp::children cs): cs_(cs) {}

    bios::file_descriptor get_stdin() const
    {
        return cs_[0].get_stdin();
    }

    bios::file_descriptor get_stdout() const
    {
        return cs_[cs_.size() - 1].get_stdout();
    }

    bios::file_descriptor get_stderr() const
    {
        return cs_[cs_.size() - 1].get_stderr();
    }

    bp::status wait()
    {
        return wait_children(cs_);
    }
};

struct launcher
{
    children_to_child
    operator()(const std::vector<std::string> args,
               bp::context ctx,
               bp::stream_behavior bstdin = bp::close_stream(),
               bp::stream_behavior bstdout = bp::close_stream(),
               bp::stream_behavior bstderr = bp::close_stream(),
               bool usein = false) const
    {
        std::vector<std::string> dummy;
        dummy.push_back("helpers");
        dummy.push_back("stdin-to-stdout");

        bp::context ctx1(ctx), ctx2(ctx);

#if defined(BOOST_PROCESS_WIN32_API)
        ctx1.stdin_behavior = bstdin;
        ctx2.stdout_behavior = bstdout;
        ctx2.stderr_behavior = bstderr;
#elif defined(BOOST_PROCESS_POSIX_API)
        ctx1.input_behavior.insert(std::make_pair(
            STDIN_FILENO, bstdin));
        ctx2.output_behavior.insert(std::make_pair(
            STDOUT_FILENO, bstdout));
        ctx2.output_behavior.insert(std::make_pair(
            STDERR_FILENO, bstderr));
#endif // #elif defined(BOOST_PROCESS_POSIX_API)

        std::vector<bp::pipeline_entry> entries;

        if (usein) {
            entries.push_back(bp::pipeline_entry(get_helpers_path(),
                                                 args, ctx1));
            entries.push_back(bp::pipeline_entry(get_helpers_path(),
                                                 dummy, ctx2));
        } else {
            entries.push_back(bp::pipeline_entry(get_helpers_path(),
                                                 dummy, ctx1));
            entries.push_back(bp::pipeline_entry(get_helpers_path(),
                                                 args, ctx2));
        }
        return launch_pipeline(entries);
    }
};

void test_exit(const std::string& middle, int value)
{
    std::vector<std::string> args1;
    args1.push_back("helpers");
    args1.push_back("exit-success");

    std::vector<std::string> args2;
    args2.push_back("helpers");
    args2.push_back(middle);

    std::vector<std::string> args3;
    args3.push_back("helpers");
    args3.push_back("exit-success");

    bp::context ctx;

    std::vector<bp::pipeline_entry> entries;
    entries.push_back(bp::pipeline_entry(get_helpers_path(), args1, ctx));
    entries.push_back(bp::pipeline_entry(get_helpers_path(), args2, ctx));
    entries.push_back(bp::pipeline_entry(get_helpers_path(), args3, ctx));
    bp::children cs = bp::launch_pipeline(entries);

    BOOST_REQUIRE(cs.size() == 3);

    const bp::status s = bp::wait_children(cs);
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), value);
}

void test_exit_failure()
{
    test_exit("exit-failure", EXIT_FAILURE);
}

void test_exit_success()
{
    test_exit("exit-success", EXIT_SUCCESS);
}

void test_simple()
{
    std::vector<std::string> args1;
    args1.push_back("helpers");
    args1.push_back("prefix");
    args1.push_back("proc1-");

    std::vector<std::string> args2;
    args2.push_back("helpers");
    args2.push_back("prefix");
    args2.push_back("proc2-");

    bp::context ctxin, ctxout;

#if defined(BOOST_PROCESS_WIN32_API)
    ctxin.stdin_behavior = bp::capture_stream();
    ctxout.stdout_behavior = bp::capture_stream();
#elif defined(BOOST_PROCESS_POSIX_API)
    ctxin.input_behavior.insert(std::make_pair(
        STDIN_FILENO, bp::capture_stream()));
    ctxout.output_behavior.insert(std::make_pair(
        STDOUT_FILENO, bp::capture_stream()));
#endif // #elif defined(BOOST_PROCESS_POSIX_API)

    std::vector<bp::pipeline_entry> entries;
    entries.push_back(bp::pipeline_entry(get_helpers_path(), args1, ctxin));
    entries.push_back(bp::pipeline_entry(get_helpers_path(), args2, ctxout));
    bp::children cs = bp::launch_pipeline(entries);

    BOOST_REQUIRE(cs.size() == 2);

    bios::stream<bios::file_descriptor> os(cs[0].get_stdin());
    os << "message" << std::endl;
    os.close();

    bios::stream<bios::file_descriptor> is(cs[1].get_stdout());
    std::string word;
    is >> word;
    BOOST_CHECK_EQUAL(word, "proc2-proc1-message");

    const bp::status s = bp::wait_children(cs);
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

void test_merge_first()
{
    std::vector<std::string> args1;
    args1.push_back("helpers");
    args1.push_back("echo-stdout-stderr");
    args1.push_back("message");

    std::vector<std::string> args2;
    args2.push_back("helpers");
    args2.push_back("prefix");
    args2.push_back("second:");

    bp::context ctxin, ctxout;

#if defined(BOOST_PROCESS_WIN32_API)
    ctxin.stderr_behavior = bp::redirect_stream_to_stdout();
    ctxout.stdout_behavior = bp::capture_stream();
#elif defined(BOOST_PROCESS_POSIX_API)
    ctxin.output_behavior.insert(std::make_pair(
        STDERR_FILENO, bp::redirect_stream_to_stdout()));
    ctxout.output_behavior.insert(std::make_pair(
        STDOUT_FILENO, bp::capture_stream()));
#endif // #elif defined(BOOST_PROCESS_POSIX_API)

    std::vector<bp::pipeline_entry> entries;
    entries.push_back(bp::pipeline_entry(get_helpers_path(), args1, ctxin));
    entries.push_back(bp::pipeline_entry(get_helpers_path(), args2, ctxout));
    bp::children cs = bp::launch_pipeline(entries);

    BOOST_REQUIRE(cs.size() == 2);

    bios::stream<bios::file_descriptor> is(cs[1].get_stdout());
    std::string word;
    is >> word;
    BOOST_CHECK_EQUAL(word, "second:stdout");
    is >> word;
    BOOST_CHECK_EQUAL(word, "message");
    is >> word;
    BOOST_CHECK_EQUAL(word, "second:stderr");
    is >> word;
    BOOST_CHECK_EQUAL(word, "message");

    const bp::status s = bp::wait_children(cs);
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

} // namespace {

bool init_unit_test()
{
    check_helpers();
//    launch_tests::add<launcher, bp::context, children_to_child>
//        (butf::master_test_suite());
//    butf::master_test_suite().add(BOOST_TEST_CASE(test_exit_success), 0, 10);
//    butf::master_test_suite().add(BOOST_TEST_CASE(test_exit_failure), 0, 10);
//    butf::master_test_suite().add(BOOST_TEST_CASE(test_simple), 0, 10);
    butf::master_test_suite().add(BOOST_TEST_CASE(test_merge_first), 0, 10);
    return true;
}
