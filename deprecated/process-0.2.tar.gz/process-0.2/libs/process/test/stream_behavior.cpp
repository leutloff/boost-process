// Boost.Process
// Tests for the stream_behavior class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "boost/process/stream_behavior.hpp"
#include "boost/test/unit_test.hpp"

namespace bp = boost::process;
namespace butf = boost::unit_test::framework;

namespace {

void test_capture()
{
    bp::stream_behavior sb = bp::capture_stream();
//    BOOST_CHECK_EQUAL(sb.get_type(), bp::stream_behavior::capture);
}

void test_close()
{
    bp::stream_behavior sb = bp::close_stream();
//    BOOST_CHECK_EQUAL(sb.get_type(), bp::stream_behavior::close);
}

void test_inherit()
{
    bp::stream_behavior sb = bp::inherit_stream();
//    BOOST_CHECK_EQUAL(sb.get_type(), bp::stream_behavior::inherit);
}

void test_redirect_to_stdout()
{
    bp::stream_behavior sb = bp::redirect_stream_to_stdout();
//    BOOST_CHECK_EQUAL(sb.get_type(), bp::stream_behavior::redirect_to_stdout);
}

void test_silence()
{
    bp::stream_behavior sb = bp::silence_stream();
//    BOOST_CHECK_EQUAL(sb.get_type(), bp::stream_behavior::silence);
}

#if defined(BOOST_PROCESS_POSIX_API)
void test_posix_redirect()
{
    bp::stream_behavior sb1 = bp::posix_redirect_stream(1);
//    BOOST_CHECK_EQUAL(sb1.get_type(), bp::stream_behavior::posix_redirect);
    // FIXME: desc_to_ is private
    // BOOST_CHECK_EQUAL(sb1.desc_to_, 1);

    bp::stream_behavior sb2 = bp::posix_redirect_stream(2);
//    BOOST_CHECK_EQUAL(sb2.get_type(), bp::stream_behavior::posix_redirect);
    // FIXME: desc_to_ is private
    // BOOST_CHECK_EQUAL(sb2.desc_to_, 2);
}
#endif // #if defined(BOOST_PROCESS_POSIX_API)

} // namespace {

bool init_unit_test()
{
    butf::master_test_suite().add(BOOST_TEST_CASE(test_capture));
    butf::master_test_suite().add(BOOST_TEST_CASE(test_close));
    butf::master_test_suite().add(BOOST_TEST_CASE(test_inherit));
    butf::master_test_suite().add(BOOST_TEST_CASE(test_redirect_to_stdout));
    butf::master_test_suite().add(BOOST_TEST_CASE(test_silence));
#if defined(BOOST_PROCESS_POSIX_API)
    butf::master_test_suite().add(BOOST_TEST_CASE(test_posix_redirect));
#endif
    return true;
}
