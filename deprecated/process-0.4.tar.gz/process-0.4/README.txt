This is checked out at 2012.07.18pm(we rename it to 0.4)
svn co http://svn.boost.org/svn/boost/sandbox/SOC/2010/process/

developed from 2010-2011.02
