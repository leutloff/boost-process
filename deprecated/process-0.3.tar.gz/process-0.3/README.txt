This is checked out at 2012.07.18pm(we rename it to 0.3)
svn co http://svn.boost.org/svn/boost/sandbox/process/

This is merged from several developers by Boris Schaeling in 2008, then add in boost sandbox at 2008-12-30, after fixing some bugs released at 2009-04.21
http://www.highscore.de/boost/process.zip
together with
http://www.highscore.de/cpp/process/index.html
